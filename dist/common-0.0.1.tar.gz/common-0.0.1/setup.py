from setuptools import setup, find_packages

setup(
    name='common',
    version="0.0.1",
    description="my common package",
    long_description="my commoooooon package",
    url='hoge',
    author='tathi',
    author_email='fuga',
    license='MIT',
    classifiers=[
        'Development Status :: 1 - Planning',
    ],
    keywords='common',
    install_requires=['mecab-python3']
)
